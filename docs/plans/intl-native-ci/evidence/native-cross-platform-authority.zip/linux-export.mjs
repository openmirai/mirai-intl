import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const args=['/work/node_modules/@openmirai/intl/dist/cli.js','authority','export','--workspace','--out','/evidence/linux-authority.tar','--format=json'];
const p=spawnSync(process.execPath,args,{cwd:'/work',encoding:'utf8',timeout:60000,maxBuffer:4*1024*1024});
writeFileSync('/evidence/export.stdout.json',p.stdout??'');writeFileSync('/evidence/export.stderr',p.stderr??'');
if(p.status!==0||p.error||p.signal)throw new Error(`Export failed: ${p.status}`);
if(JSON.parse(p.stdout).success!==true)throw new Error('Unsuccessful export');
