import { GREETING_KEY } from "receipt-provider";
import { useTranslations } from "x";
const { t } = useTranslations("receipt");
export const page = t(GREETING_KEY);
export type PagePromise = Promise<string>;
