import {spawnSync} from 'node:child_process';
import {writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const cli='/work/node_modules/@openmirai/intl/dist/cli.js';
const archiveBefore=hash('/input/authority.tar');
const commands=[['authority','import','--workspace','--from','/input/authority.tar','--format=json'],['verify','--workspace','--format=json']];
for(const [index,args] of commands.entries()){
 const result=spawnSync(process.execPath,[cli,...args],{cwd:'/work',encoding:'utf8',timeout:60000,maxBuffer:4*1024*1024});
 writeFileSync(`/evidence/${index}.stdout.json`,result.stdout??'');
 writeFileSync(`/evidence/${index}.stderr`,result.stderr??'');
 if(result.status!==0||result.error||result.signal)throw new Error(`Portability command ${index} failed: ${result.status} ${result.error?.message??''}`);
 const report=JSON.parse(result.stdout);if(report.success!==true)throw new Error('Unsuccessful portability report');
 if(index===1){for(const [key,value] of Object.entries({verifiedCatalogs:1,buildReceiptVerifications:1,catalogCompilations:0,artifactEmissions:0,buildSemanticAnalysisRuns:0})){if(report.summary[key]!==value)throw new Error(`Wrong proof counter ${key}`);}}
}
const native='/work/node_modules/@openmirai/intl-compiler/native/engine-manifest.json';
const manifest=JSON.parse(readFileSync(native,'utf8'));
const target=manifest.targets['linux-arm64-gnu'];
if('sha256:'+hash('/work/node_modules/@openmirai/intl-compiler/native/'+target.file)!==target.hash)throw new Error('Target binary mismatch');
if(hash('/input/authority.tar')!==archiveBefore)throw new Error('Transferred archive changed');
writeFileSync('/evidence/result.json',JSON.stringify({success:true,platform:process.platform,arch:process.arch,node:process.version,engine:process.env.MIRAI_INTL_ENGINE,commands,archiveSha256:archiveBefore,nativeManifestSha256:hash(native),target,compilerVersion:manifest.compilerVersion},null,2)+'\n');
