export PATH=/Users/kentakoong/.nvm/versions/node/v24.18.0/bin:$PATH
node_modules/.bin/oxlint packages/compiler/test/authority-bundle.test.ts
node_modules/.bin/oxfmt --check packages/compiler/test/authority-bundle.test.ts
node_modules/.bin/tsc -p tsconfig.tools.json --pretty false --incremental false
git diff --check -- packages/compiler/test/authority-bundle.test.ts
shasum -a 256 packages/compiler/src/authority-bundle.ts packages/compiler/test/authority-bundle.test.ts packages/compiler/native/engine-manifest.json packages/compiler/native/mirai-intl-darwin-arm64.node
git diff --name-only
rg -n 'transfer transaction boundary fault injection|it.each\(boundaries\)|it.each\(rollbackBoundaries\)' packages/compiler/test/authority-bundle.test.ts
git rev-parse HEAD
