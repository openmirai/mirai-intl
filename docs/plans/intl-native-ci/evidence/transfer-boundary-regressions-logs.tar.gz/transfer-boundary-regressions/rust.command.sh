export PATH=/Users/kentakoong/.nvm/versions/node/v24.18.0/bin:$PATH
ROLLBACK_TEST_ENGINE=rust python3 - <<'PY'
import os, subprocess, tempfile
scratch = tempfile.mkdtemp(prefix='intl-rollback-pnpm-', dir='/private/tmp')
env = dict(os.environ)
env.update(XDG_CONFIG_HOME=scratch, npm_config_userconfig=scratch+'/npmrc', npm_config_globalconfig=scratch+'/globalrc', MIRAI_INTL_ENGINE=os.environ['ROLLBACK_TEST_ENGINE'])
command = ['corepack', 'pnpm', '--config.verify-deps-before-run=false', 'exec', 'vitest', 'run', 'packages/compiler/test/authority-bundle.test.ts', '--maxWorkers', '1', '--testTimeout', '30000', '--hookTimeout', '60000']
print('ENGINE='+env['MIRAI_INTL_ENGINE']+'; deadline=180s; config='+scratch, flush=True)
result = subprocess.run(command, env=env, timeout=180)
raise SystemExit(result.returncode)
PY
