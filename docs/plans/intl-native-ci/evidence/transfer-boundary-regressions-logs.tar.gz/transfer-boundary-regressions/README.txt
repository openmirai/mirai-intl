Retained execution evidence, exported without rerunning commands.
node.log and rust.log concatenate the exact initial and final non-empty console chunks from the successful final runs. Intervening polls were empty. These are the complete emitted default-reporter summaries, not verbose per-case logs.
*.command.sh contain the exact expanded shell commands from those execution records.
validation-batch.log is the exact combined output of validation-batch.command.sh. The batch returned 0 and the typecheck emitted no diagnostics. Individual typecheck/lint/format/diff exit codes were not separately captured; the shell batch did not use set -e. No isolated typecheck.log or standalone success record is fabricated.
Only allowlisted public compiler test logs and command strings are included. No raw conversation, private application source, fixtures, authority archives, environment dumps, or credentials are included.
